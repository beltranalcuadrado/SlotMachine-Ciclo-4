
/**
 * Símbolo gigante: arranca pequeño y cada vez que es seleccionado en una
 * rueda crece, hasta llegar a un tamaño máximo.
 *
 * @author (Wilmar Beltran, Santiago Hernández)
 * @version (ciclo 4)
 */
public class GiantSymbol extends Symbol{
    private int size;
    private static final int TAMANO_INICIAL = 10;
    private static final int INCREMENTO = 10;
    private static final int TAMANO_MAXIMO = 50;
    
    /**
    * Crea un símbolo gigante de un color dado con el tamaño inicial.
    *
    * @param color Color del símbolo
    */
    public GiantSymbol(String color){
        super(color);
        size = TAMANO_INICIAL;
    }
    
    /**
    * Consulta el tamaño actual del símbolo.
    *
    * @return Tamaño actual, que aumenta con cada selección
    */
    @Override
    public int getSize(){
        return size;
    }
    
    /**
    * Hace crecer el símbolo cada vez que es seleccionado, sin pasar del tamaño máximo.
    */
    @Override 
    public void onSelected(){
        if (size < TAMANO_MAXIMO){
          size += INCREMENTO;
          if(size > TAMANO_MAXIMO){ //Si el tamaño queda mayor a 50, entonces lo ponemos en 50
              size = TAMANO_MAXIMO;
          }
        }
    }
}