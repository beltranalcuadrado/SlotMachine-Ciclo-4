
/**
 * Símbolo tímido: cada vez que es seleccionado en una rueda alterna
 * entre visible e invisible.
 *
 * @author (Wilmar Beltran, Santiago Hernández)
 * @version (ciclo 4)
 */
public class ShySymbol extends Symbol{
    private boolean shown;
    
    /**
    * Crea un símbolo tímido de un color dado. Arranca en false, es decir, escondido, para que
    * la primera vez que es seleccionado en una rueda se vea.
    *
    * @param color Color del símbolo
    */
    public ShySymbol(String color){
        super(color);
        shown = false; 
    }
    
    /**
    * Consulta si el símbolo se debe dibujar en la ventanilla.
    *
    * @return true si está visible, false si está escondido
    */
    @Override
    public boolean isShown(){
        return shown;
    }
    
    /**
    * Alterna el símbolo entre visible e invisible cada vez que es seleccionado.
    */
    @Override
    public void onSelected(){
        shown = !shown; //Cambia el estado del simbolo
    }
}