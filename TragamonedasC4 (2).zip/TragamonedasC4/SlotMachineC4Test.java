

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


/**
 * Pruebas de unidad del ciclo 4 para los tipos de ruedas y símbolos.
 * Todas las pruebas corren en modo invisible.
 *
 * @author (Wilmar Beltran, Santiago Hernández)
 * @version (ciclo 4)
 */
public class SlotMachineC4Test {

    private SlotMachine sm;

    @BeforeEach
    public void setUp(){
        sm = new SlotMachine();
        sm.makeInvisible(); // por defecto ya nace invisible, pero lo dejamos explícito
    }

    @Test
    public void deberiaCrearRuedaRebelde(){
        sm.addWheel("rebel", 1);
        assertTrue(sm.ok());
        assertEquals(1, sm.configuration().length);
    }
    
    @Test
    public void noDeberiaCrearTipoDeRuedaInexistente(){
        sm.addWheel("raro", 1);
        assertFalse(sm.ok());
        assertEquals(0, sm.configuration().length);
    }
    
    @Test
    public void noDeberiaBloquearRuedaRebelde(){
        sm.addWheel("rebel", 1);
        sm.lock(1);
        assertFalse(sm.ok());
    }
    
    @Test
    public void noDeberiaIntercambiarRuedaRebelde(){
        sm.addWheel("normal", 1);
        sm.addWheel("rebel", 2);
        sm.swap(1, 2);
        assertFalse(sm.ok());
    }
    
    @Test
    public void noDeberiaEliminarRuedaRebelde(){
        sm.addWheel("rebel", 1);
        sm.delWheel(1);
        assertFalse(sm.ok());
        assertEquals(1, sm.configuration().length);
    }
    
    @Test
    public void deberiaCopiarSimboloDeLaIzquierdaAlGirarLefty(){
        sm.addWheel("normal", 1);
        sm.addWheel("lefty", 2);  
        sm.addSymbol(1, "red");
        sm.addSymbol(2, "blue");
        sm.addSymbol(3, "green");
        sm.placeSymbol(1, "red");
        sm.placeSymbol(1, "blue");
        sm.placeSymbol(1, "green");
        sm.placeSymbol(2, "red");
        sm.placeSymbol(2, "blue");
        sm.placeSymbol(2, "green");
        sm.spin(new String[]{"green", "red"}); //como asignamos manualmente los colores, la rueda lefty aun no hace su funcion
        sm.spin(2,1);
        assertTrue(sm.ok());
        assertEquals("green", sm.configuration()[1]);
    }
    
    @Test
    public void deberiaEncogerSimboloEfimeroAlSerSeleccionado(){
        EphemeralSymbol simbolo = new EphemeralSymbol("red"); //Arranca en tamaño 50
        simbolo.onSelected();
        assertEquals(40, simbolo.getSize());
    }
    
    @Test
    public void noDeberiaEncogerSimboloEfimeroMenosDelMinimo(){
        EphemeralSymbol simbolo = new EphemeralSymbol("blue");
        for (int i = 0; i <= 10; i++){
            simbolo.onSelected();
        }
        assertEquals(5, simbolo.getSize());
    }
    
    @Test
    public void deberiaAlternarVisibilidadDelSimboloTimido(){
        ShySymbol simbolo = new ShySymbol("green");
        assertFalse(simbolo.isShown()); //Verifica que arranque en false
        simbolo.onSelected();
        assertTrue(simbolo.isShown()); //Despues de un movimiento cambia de estado
        simbolo.onSelected();
        assertFalse(simbolo.isShown());
    }
    
    @Test
    public void deberiaCrecerSimboloGiganteHastaElMaximo(){
        GiantSymbol simbolo = new GiantSymbol("red"); //Arranca en 10 de tamaño
        simbolo.onSelected();
        assertEquals(20, simbolo.getSize());
        for(int i = 0; i <= 10; i++){
            simbolo.onSelected();
        }
        assertEquals(50, simbolo.getSize());
    }
    
    @Test
    public void noDeberiaCrearTipoSimboloInexistente(){
        sm.addSymbol("raro", 1, "red");
        assertFalse(sm.ok());
        assertEquals(0, sm.symbols().length);
    }
}