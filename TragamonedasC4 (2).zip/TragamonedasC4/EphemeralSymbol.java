
/**
 * Símbolo efímero: cada vez que es seleccionado en una rueda se encoge,
 * hasta quedar del tamaño de un punto.
 *
 * @author (Wilmar Beltran, Santiago Hernández)
 * @version (ciclo 4)
 */
public class EphemeralSymbol extends Symbol{
    private int size;
    private static final int TAMANO_INICIAL = 50;
    private static final int DECREMENTO = 10;
    private static final int TAMANO_MINIMO = 5;
    
    /**
    * Constructor de la clase, crea el simbolo de un color dado con el tamaño inicial 
    * 
    * @param color Color del símbolo
    */
    public EphemeralSymbol(String color){
        super(color);
        size = TAMANO_INICIAL;
    }
    
    /**
    * Consulta el tamaño actual del símbolo.
    *
    * @return Tamaño actual, que disminuye con cada selección
    */
    @Override
    public int getSize(){
        return size;
    }
    
    /**
    * Encoge el símbolo cada vez que es seleccionado, sin bajar del tamaño mínimo.
    */
    @Override 
    public void onSelected(){
        if (size > TAMANO_MINIMO){
          size -= DECREMENTO;
          if(size < TAMANO_MINIMO){ //Si el tamaño queda menor a 5 entonces lo ponemos en 5.
              size = TAMANO_MINIMO;
          }
        }
    }
}