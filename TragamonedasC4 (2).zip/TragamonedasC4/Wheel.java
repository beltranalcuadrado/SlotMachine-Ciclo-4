import java.util.ArrayList;

/**
 * Representa una rueda de la máquina tragaperras. Guarda los símbolos que tiene
 * montados y el símbolo que se ve en la ventanilla después de girar. Además
 * puede bloquearse para que no gire.
 * 
 * @author Santiago Hernández - Wilmar Beltran
 * @version (20 september 2026)
 */
public class Wheel {

    private ArrayList<Symbol> symbols;    
    private Symbol visible;
    private boolean locked;
    private Circle window;

    public Wheel() {
        symbols = new ArrayList<>();  
        visible = null;         
        locked = false;               
    }
    
    /**
    * Agrega un símbolo a la lista de símbolos de la rueda.
    *
    * @param symbol Símbolo que se añade a la rueda
    */
    public void mountSymbol(Symbol symbol) {
        symbols.add(symbol);
    }

    /**
     * Gira la rueda escogiendo al azar uno de sus símbolos, que pasa a ser el visible.
     * No gira si la rueda está bloqueada o si no tiene símbolos.
     *
     * @return true si la rueda giró, false si estaba bloqueada o vacía
     */
    public boolean rotate() {
        if (locked) {
            return false;
        }
        if (symbols.isEmpty()) {
            return false; 
        }
        int indice = (int) (Math.random() * symbols.size());
        visible = symbols.get(indice);
        visible.onSelected();
        return true;
    }

    /**
    * Consulta el color del símbolo que se ve en la ventanilla de la rueda.
    *
    * @return Color del símbolo visible, o null si la rueda todavía no ha girado
    */
    public String getVisibleColor() {
        if (visible != null){
            return visible.getColor();
        }
        else {
            return null;
        }
    }

    /**
    * Bloquea una rueda para que no pueda girar
    */
    public void lock() {
        locked = true;
    }
    
    /**
    * Desbloquea una rueda para que pueda volver a girar
    */
    public void unlock() {
        locked = false;
    }

    /**
    * Consulta si la rueda está bloqueada.
    *
    * @return true si la rueda está bloqueada, false en caso contrario
    */
    public boolean isLocked() {
        return locked;
    }
    
    /**
    * Avanza la rueda una posición sobre sus símbolos, y el siguiente pasa a ser el visible.
    * Si llega al último símbolo, vuelve al primero. Si la rueda aún no había girado,
    * se cuenta como si estuviera en el primer símbolo.
    * No avanza si la rueda está bloqueada o si no tiene símbolos.
    *
    * @return true si la rueda avanzó, false si estaba bloqueada o vacía
    */
    public boolean advance() {
        if (locked || symbols.isEmpty()){
            return false;
        }
        
        else{
            int index = symbols.indexOf(visible);
            if (index == -1) {
                index = 0;
            }
            
            index = index + 1;
            if (index >= symbols.size()){
                index = 0;
            }
            visible = symbols.get(index);
            visible.onSelected();
            return true;
        }
    }
    
    /**
    * Establece directamente el símbolo que se ve en la ventanilla de la rueda,
    * sin girarla. No verifica si el símbolo está montado en la rueda ni si está bloqueada.
    *
    * @param symbol Símbolo que pasa a ser el visible
    */
    public void setVisible(Symbol symbol) {
        visible = symbol;
    }
    
    //Ciclo 4
    /**
    * Indica si la rueda se deja bloquear.
    *
    * @return true, una rueda normal siempre se deja bloquear
    */
    public boolean canBeLocked(){
        return true;
    }
    
    /**
    * Indica si la rueda se deja intercambiar.
    *
    * @return true, una rueda normal siempre se deja intercambiar
    */
    public boolean canBeSwapped(){
        return true;
    }
    
    /**
    * Indica si la rueda se deja eliminar.
    *
    * @return true, una rueda normal siempre se deja eliminar
    */
    public boolean canBeDeleted(){
        return true;
    }
    
    /**
    * Consulta el símbolo que se ve en la ventanilla de la rueda.
    *
    * @return Símbolo visible, o null si la rueda todavía no ha girado
    */
    public Symbol getVisibleSymbol(){
        return visible;
    }
    
    /**
    * Se ejecuta después de que la rueda gira. Una rueda normal no hace nada;
    * los tipos de rueda que reaccionan al girar sobrescriben este método.
    *
    * @param left Rueda que está a la izquierda, o null si no hay
    */
    public void afterSpin(Wheel left){
    }
    
    /**
    * Dibuja la rueda en la posición indicada con el símbolo que tiene en la ventanilla.
    * Usa el color, el tamaño y la visibilidad del símbolo; si la rueda todavía no ha
    * girado, se dibuja negra. Si hay jackpot, la figura se dibuja más grande.
    *
    * @param x Posición horizontal donde se dibuja
    * @param y Posición vertical donde se dibuja
    * @param jackpot true si la máquina está en estado ganador
    */
    public void draw(int x, int y, boolean jackpot){
        erase();
        String color = "black";   // valores por si no hay símbolo
        int size = 40;
        boolean shown = true;
        
        if(visible != null){
            color = visible.getColor();
            size = visible.getSize();
            shown = visible.isShown();
        }
        
        if(jackpot){
            size += 20;
        }
        
        if(shown){
            drawShape(x, y, size, color);
        }
    }
    
    /**
    * Borra del lienzo la figura que la rueda tenga dibujada.
    */
    public void erase(){
        if (window != null){
            window.makeInvisible();
        }
    }
    
    /**
    * Dibuja la figura de la rueda: un círculo del color y tamaño dados.
    * Las ruedas de otro tipo sobrescriben este método para verse distinto.
    *
    * @param x Posición horizontal donde se dibuja
    * @param y Posición vertical donde se dibuja
    * @param size Tamaño de la figura
    * @param color Color de la figura
    */
    public void drawShape(int x, int y, int size, String color){
        window = new Circle(); // nace en (20, 15), tamaño 30, invisible
        window.changeSize(size);
        window.changeColor(color);
        window.moveHorizontal(x - 20);
        window.moveVertical(y - 15);
        window.makeVisible(); // ya en su sitio, la mostramos
    }
}