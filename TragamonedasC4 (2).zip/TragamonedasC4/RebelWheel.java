
/**
 * Rueda RebelWheel: se comporta como una rueda normal al girar,
 * pero no se deja bloquear, ni intercambiar, ni eliminar.
 *
 * @author (Wilmar Beltran, Santiago Hernández)
 * @version (ciclo 4)
 */
public class RebelWheel extends Wheel{
    private Rectangle square;
    
    /**
    * Indica si la rueda se deja bloquear
    * 
    * @return false, una rueda RebelWheel no se deja bloquear
    */
    @Override
    public boolean canBeLocked(){
        return false;
    }
    
    /**
    * Indica si la rueda se deja intercambiar
    * 
    * @return false, una rueda RebelWheel no se deja intercambiar
    */
    @Override
    public boolean canBeSwapped(){
        return false;
    }
    
    /**
    * Indica si la rueda se deja eliminar
    * 
    * @return false, una rueda RebelWheel no se deja eliminar
    */
    @Override
    public boolean canBeDeleted(){
        return false;
    }
    
    /**
    * Dibuja la rueda rebelde como un cuadrado del color y tamaño dados,
    * para distinguirla de las ruedas normales.
    *
    * @param x Posición horizontal donde se dibuja
    * @param y Posición vertical donde se dibuja
    * @param size Tamaño del cuadrado
    * @param color Color del cuadrado
    */
    @Override
    public void drawShape(int x, int y, int size, String color){
        square = new Rectangle();
        square.changeSize(size, size); // alto y ancho iguales = cuadrado
        square.changeColor(color);
        square.moveHorizontal(x - 70); // el Rectangle nace en x = 70
        square.moveVertical(y - 15);
        square.makeVisible();
    }
    
    /**
    * Borra del lienzo el cuadrado de la rueda rebelde.
    */
    @Override
    public void erase(){
        if (square != null){
            square.makeInvisible();
        }
    }
}