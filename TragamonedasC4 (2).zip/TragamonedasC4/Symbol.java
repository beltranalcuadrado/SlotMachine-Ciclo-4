
/**
 * Clase que se encarga del tema de los colores de los simbolos.
 * 
 * @author (Santiago Hernandez, Wilmar Beltran) 
 * @version (a version number or a date)
 */
public class Symbol {
    private String color;
    
    public Symbol(String color){
        this.color = color; //Se asigna un color en el constructor
    }
    
    /**
     * Obtiene el color actual del simbolo
     * 
     * @return color del simbolo
     */
    public String getColor(){
        return color;
    }
    
    /**
     * Asigna un color al simbolo
     * 
     * @param color a asignar al simbolo
     */
    public void setColor(String color){
        this.color = color; //Cambia el color de un śimbolo cuantas veces se quiera
    }
    
    //ciclo 4
    /**
    * Consulta el tamaño con el que se dibuja el símbolo.
    *
    * @return 40, un símbolo normal siempre tiene el mismo tamaño
    */
    public int getSize(){
        return 40;
    }
    
    /**
    * Consulta si el símbolo se debe dibujar en la ventanilla.
    *
    * @return true, un símbolo normal siempre se ve
    */
    public boolean isShown(){
        return true;
    }
    
    /**
    * Se ejecuta cada vez que el símbolo queda en la ventanilla de una rueda.
    * Un símbolo normal no hace nada; los tipos de símbolo que reaccionan
    * al ser seleccionados sobrescriben este método.
    */
    public void onSelected(){
    }
}
