/**
 * Rueda izquierda: gira como una rueda normal, pero al terminar de girar
 * copia el símbolo visible de la rueda que tiene a su izquierda.
 * Si no tiene rueda a su izquierda, se comporta como una rueda normal.
 *
 * @author (Wilmar Beltran, Santiago Hernández)
 * @version (ciclo 4)
 */
public class LeftyWheel extends Wheel{
    private Triangle arrow;
    
    /**
    * Después de girar, copia el símbolo visible de la rueda de su izquierda.
    * Si no hay rueda a la izquierda, no hace nada.
    *
    * @param left Rueda que está a la izquierda, o null si no hay
    */
    @Override
    public void afterSpin(Wheel left){
        if(left != null){
            setVisible(left.getVisibleSymbol());
        }
    }
    
    /**
    * Dibuja la rueda left como una rueda normal más una flecha que apunta
    * hacia la izquierda, para indicar que copia a la rueda de su izquierda.
    *
    * @param x Posición horizontal donde se dibuja
    * @param y Posición vertical donde se dibuja
    * @param size Tamaño del círculo
    * @param color Color del círculo
    */
    @Override
    public void drawShape(int x, int y, int size, String color){
        super.drawShape(x, y, size, color);  //Para hacer el circulo como lo hace el metodo en la clase padre
        arrow = new Triangle();
        arrow.changeSize(12, 16);   //De aca para adelante es para hacer la flecha pequeña
        arrow.changeColor("black");
        arrow.pointLeft();
        arrow.moveHorizontal((x - 15) - 140);      
        arrow.moveVertical((y + size / 2) - 15);    
        arrow.makeVisible();
    }
    
    /**
    * Borra del lienzo el círculo y la flecha de la rueda zurda.
    */
    @Override
    public void erase(){
        super.erase();                // borra el círculo
        if (arrow != null){
            arrow.makeInvisible();    // borra la flecha
        }
    }
}