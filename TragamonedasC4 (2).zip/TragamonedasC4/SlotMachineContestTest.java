

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * Pruebas de unidad de SlotMachineContest: verifican que solve llegue al
 * jackpot, respete el límite de acciones y devuelva un camino válido.
 *
 * @author (Wilmar Beltran, Santiago Hernández)
 * @version (ciclo 3)
 */
public class SlotMachineContestTest
{
    /**
     * Default constructor for test class SlotMachineContestTest
     */
    public SlotMachineContestTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @AfterEach
    public void tearDown()
    {
    }
    
    @Test
    public void deberiaLlegarAlJackpotConPocasRuedas(){
        SlotMachine sm = new SlotMachine(3);
        SlotMachineContest.solve(sm, 3);
        assertTrue(sm.isJackpot());
    }
    
    @Test
    public void  deberiaLlegarAlJackpotConRuedasMedianas(){
        SlotMachine sm = new SlotMachine(10);
        SlotMachineContest.solve(sm, 10);
        assertTrue(sm.isJackpot());
    }
    
    @Test
    public void deberiaLlegarAlJackpotConMuchasRuedas(){
        SlotMachine sm = new SlotMachine(50);
        SlotMachineContest.solve(sm, 50);
        assertTrue(sm.isJackpot());
    }
    
    @Test
    public void noDeberiaPasarseDelLimiteDeAcciones(){
        SlotMachine sm = new SlotMachine(50);
        int[][] actions = SlotMachineContest.solve(sm, 50);
        assertTrue(actions.length <= 10000);
    }
    
    @Test
    public void deberiaDevolverAccionesConRuedasValidas(){
        SlotMachine sm = new SlotMachine(10);
        int[][] actions = SlotMachineContest.solve(sm, 10);
        for (int i = 0; i < actions.length; i++){
            assertTrue(actions[i][0] >= 1 && actions[i][0] <= 10); //Cada rueda esta entre el rango de 1 y 10.
        }
    }
    
    @Test
    public void deberiaLlegarAlJackpotEnVariasMaquinasAlAzar(){
        for(int i = 0; i <= 30; i++){
            int n = 3 + (int) (Math.random() * 48);
            SlotMachine sm = new SlotMachine(n);
            SlotMachineContest.solve(sm, n);
            assertTrue(sm.isJackpot());
        }
    }
    
    @Test
    public void deberiaLlegarAlJackpotSiguiendoLasAccionesDevueltas(){
        SlotMachine sm = new SlotMachine(10);
        String[] inicial = sm.configuration();
        int[][] acciones = SlotMachineContest.solve(sm, 10);
        
        SlotMachine copia = new SlotMachine(10);
        copia.spin(inicial);
        for (int i = 0; i < acciones.length; i++){
            copia.spin(acciones[i][0], acciones[i][1]);
        }
        assertTrue(copia.isJackpot());
    }
}